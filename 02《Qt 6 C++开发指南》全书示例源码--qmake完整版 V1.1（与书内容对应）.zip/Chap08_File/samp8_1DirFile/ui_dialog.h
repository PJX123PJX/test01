/********************************************************************************
** Form generated from reading UI file 'dialog.ui'
**
** Created by: Qt User Interface Compiler version 6.2.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOG_H
#define UI_DIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QToolBox>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Dialog
{
public:
    QVBoxLayout *verticalLayout_10;
    QSplitter *splitter;
    QToolBox *toolBox;
    QWidget *pageApp;
    QVBoxLayout *verticalLayout_3;
    QGroupBox *groupBox_8;
    QVBoxLayout *verticalLayout_2;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_62;
    QPushButton *pushButton_4;
    QPushButton *pushButton_61;
    QPushButton *pushButton_40;
    QWidget *pageFile;
    QVBoxLayout *verticalLayout_8;
    QGroupBox *groupBox_10;
    QGridLayout *gridLayout_7;
    QPushButton *pushButton_48;
    QPushButton *pushButton_49;
    QPushButton *pushButton_50;
    QPushButton *pushButton_51;
    QPushButton *pushButton_63;
    QGroupBox *groupBox_9;
    QGridLayout *gridLayout_5;
    QPushButton *pushButton_53;
    QPushButton *pushButton_56;
    QPushButton *pushButton_55;
    QPushButton *pushButton_54;
    QPushButton *pushButton_64;
    QWidget *pageFileInfo;
    QVBoxLayout *verticalLayout_5;
    QGroupBox *groupBox_6;
    QGridLayout *gridLayout_4;
    QPushButton *pushButton_30;
    QPushButton *pushButton_29;
    QPushButton *pushButton_28;
    QPushButton *pushButton_31;
    QPushButton *pushButton_42;
    QPushButton *pushButton_43;
    QPushButton *pushButton_35;
    QPushButton *pushButton_36;
    QPushButton *pushButton_44;
    QPushButton *pushButton_33;
    QPushButton *pushButton_27;
    QPushButton *pushButton_39;
    QPushButton *pushButton_59;
    QPushButton *pushButton_32;
    QPushButton *pushButton_34;
    QPushButton *pushButton_37;
    QPushButton *pushButton_38;
    QPushButton *pushButton_58;
    QWidget *pageDir;
    QVBoxLayout *verticalLayout_4;
    QGroupBox *groupBox;
    QGridLayout *gridLayout_3;
    QPushButton *pushButton_8;
    QPushButton *pushButton_10;
    QPushButton *pushButton_9;
    QPushButton *pushButton_7;
    QPushButton *pushButton_6;
    QPushButton *pushButton_60;
    QGroupBox *groupBox_4;
    QGridLayout *gridLayout_2;
    QPushButton *pushButton_20;
    QPushButton *pushButton_22;
    QPushButton *pushButton_23;
    QPushButton *pushButton_26;
    QPushButton *pushButton_24;
    QPushButton *pushButton_12;
    QGroupBox *groupBox_3;
    QGridLayout *gridLayout;
    QPushButton *pushButton_19;
    QPushButton *pushButton_11;
    QPushButton *pushButton_17;
    QPushButton *pushButton_14;
    QPushButton *pushButton_15;
    QPushButton *pushButton_18;
    QPushButton *pushButton_13;
    QPushButton *pushButton_65;
    QPushButton *pushButton_16;
    QPushButton *pushButton_66;
    QWidget *pageTempDir;
    QHBoxLayout *horizontalLayout_2;
    QGroupBox *groupBox_5;
    QVBoxLayout *verticalLayout_7;
    QPushButton *pushButton_21;
    QPushButton *pushButton_67;
    QPushButton *pushButton_68;
    QWidget *pageTempFile;
    QVBoxLayout *verticalLayout_11;
    QGroupBox *groupBox_12;
    QVBoxLayout *verticalLayout_12;
    QPushButton *pushButton_25;
    QPushButton *pushButton_69;
    QPushButton *pushButton_70;
    QWidget *pageWatcher;
    QVBoxLayout *verticalLayout_9;
    QGroupBox *groupBox_11;
    QVBoxLayout *verticalLayout_6;
    QPushButton *pushButton_46;
    QPushButton *pushButton_47;
    QPushButton *pushButton_52;
    QPushButton *pushButton_57;
    QGroupBox *groupBox_2;
    QVBoxLayout *verticalLayout;
    QGroupBox *groupBox_7;
    QHBoxLayout *horizontalLayout;
    QPushButton *pushButton_41;
    QPushButton *pushButton_45;
    QPushButton *pushButton_5;
    QGridLayout *gridLayout_6;
    QLabel *label;
    QLineEdit *editFile;
    QLabel *label_2;
    QLineEdit *editDir;
    QLabel *label_3;
    QPlainTextEdit *plainTextEdit;

    void setupUi(QDialog *Dialog)
    {
        if (Dialog->objectName().isEmpty())
            Dialog->setObjectName(QString::fromUtf8("Dialog"));
        Dialog->resize(927, 616);
        QFont font;
        font.setPointSize(10);
        Dialog->setFont(font);
        verticalLayout_10 = new QVBoxLayout(Dialog);
        verticalLayout_10->setSpacing(6);
        verticalLayout_10->setContentsMargins(11, 11, 11, 11);
        verticalLayout_10->setObjectName(QString::fromUtf8("verticalLayout_10"));
        splitter = new QSplitter(Dialog);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setOrientation(Qt::Horizontal);
        toolBox = new QToolBox(splitter);
        toolBox->setObjectName(QString::fromUtf8("toolBox"));
        toolBox->setMaximumSize(QSize(400, 16777215));
        toolBox->setFrameShape(QFrame::StyledPanel);
        pageApp = new QWidget();
        pageApp->setObjectName(QString::fromUtf8("pageApp"));
        pageApp->setGeometry(QRect(0, 0, 342, 379));
        verticalLayout_3 = new QVBoxLayout(pageApp);
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setContentsMargins(11, 11, 11, 11);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        groupBox_8 = new QGroupBox(pageApp);
        groupBox_8->setObjectName(QString::fromUtf8("groupBox_8"));
        verticalLayout_2 = new QVBoxLayout(groupBox_8);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        pushButton = new QPushButton(groupBox_8);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setMinimumSize(QSize(0, 25));

        verticalLayout_2->addWidget(pushButton);

        pushButton_2 = new QPushButton(groupBox_8);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setMinimumSize(QSize(0, 25));

        verticalLayout_2->addWidget(pushButton_2);

        pushButton_3 = new QPushButton(groupBox_8);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setMinimumSize(QSize(0, 25));

        verticalLayout_2->addWidget(pushButton_3);

        pushButton_62 = new QPushButton(groupBox_8);
        pushButton_62->setObjectName(QString::fromUtf8("pushButton_62"));
        pushButton_62->setMinimumSize(QSize(0, 25));

        verticalLayout_2->addWidget(pushButton_62);

        pushButton_4 = new QPushButton(groupBox_8);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setMinimumSize(QSize(0, 25));

        verticalLayout_2->addWidget(pushButton_4);

        pushButton_61 = new QPushButton(groupBox_8);
        pushButton_61->setObjectName(QString::fromUtf8("pushButton_61"));
        pushButton_61->setMinimumSize(QSize(0, 25));

        verticalLayout_2->addWidget(pushButton_61);

        pushButton_40 = new QPushButton(groupBox_8);
        pushButton_40->setObjectName(QString::fromUtf8("pushButton_40"));
        pushButton_40->setMinimumSize(QSize(0, 25));

        verticalLayout_2->addWidget(pushButton_40);


        verticalLayout_3->addWidget(groupBox_8);

        QIcon icon;
        icon.addFile(QString::fromUtf8(":/images/images/802.bmp"), QSize(), QIcon::Normal, QIcon::Off);
        toolBox->addItem(pageApp, icon, QString::fromUtf8("QCoreApplication\347\261\273"));
        pageFile = new QWidget();
        pageFile->setObjectName(QString::fromUtf8("pageFile"));
        pageFile->setGeometry(QRect(0, 0, 342, 379));
        verticalLayout_8 = new QVBoxLayout(pageFile);
        verticalLayout_8->setSpacing(6);
        verticalLayout_8->setContentsMargins(11, 11, 11, 11);
        verticalLayout_8->setObjectName(QString::fromUtf8("verticalLayout_8"));
        groupBox_10 = new QGroupBox(pageFile);
        groupBox_10->setObjectName(QString::fromUtf8("groupBox_10"));
        gridLayout_7 = new QGridLayout(groupBox_10);
        gridLayout_7->setSpacing(6);
        gridLayout_7->setContentsMargins(11, 11, 11, 11);
        gridLayout_7->setObjectName(QString::fromUtf8("gridLayout_7"));
        pushButton_48 = new QPushButton(groupBox_10);
        pushButton_48->setObjectName(QString::fromUtf8("pushButton_48"));
        pushButton_48->setMinimumSize(QSize(0, 25));

        gridLayout_7->addWidget(pushButton_48, 0, 0, 1, 1);

        pushButton_49 = new QPushButton(groupBox_10);
        pushButton_49->setObjectName(QString::fromUtf8("pushButton_49"));
        pushButton_49->setMinimumSize(QSize(0, 25));

        gridLayout_7->addWidget(pushButton_49, 1, 0, 1, 1);

        pushButton_50 = new QPushButton(groupBox_10);
        pushButton_50->setObjectName(QString::fromUtf8("pushButton_50"));
        pushButton_50->setMinimumSize(QSize(0, 25));

        gridLayout_7->addWidget(pushButton_50, 1, 1, 1, 1);

        pushButton_51 = new QPushButton(groupBox_10);
        pushButton_51->setObjectName(QString::fromUtf8("pushButton_51"));
        pushButton_51->setMinimumSize(QSize(0, 25));

        gridLayout_7->addWidget(pushButton_51, 0, 1, 1, 1);

        pushButton_63 = new QPushButton(groupBox_10);
        pushButton_63->setObjectName(QString::fromUtf8("pushButton_63"));
        pushButton_63->setMinimumSize(QSize(0, 25));

        gridLayout_7->addWidget(pushButton_63, 2, 0, 1, 1);


        verticalLayout_8->addWidget(groupBox_10);

        groupBox_9 = new QGroupBox(pageFile);
        groupBox_9->setObjectName(QString::fromUtf8("groupBox_9"));
        gridLayout_5 = new QGridLayout(groupBox_9);
        gridLayout_5->setSpacing(6);
        gridLayout_5->setContentsMargins(11, 11, 11, 11);
        gridLayout_5->setObjectName(QString::fromUtf8("gridLayout_5"));
        pushButton_53 = new QPushButton(groupBox_9);
        pushButton_53->setObjectName(QString::fromUtf8("pushButton_53"));
        pushButton_53->setMinimumSize(QSize(0, 25));

        gridLayout_5->addWidget(pushButton_53, 0, 0, 1, 1);

        pushButton_56 = new QPushButton(groupBox_9);
        pushButton_56->setObjectName(QString::fromUtf8("pushButton_56"));
        pushButton_56->setMinimumSize(QSize(0, 25));

        gridLayout_5->addWidget(pushButton_56, 2, 1, 1, 1);

        pushButton_55 = new QPushButton(groupBox_9);
        pushButton_55->setObjectName(QString::fromUtf8("pushButton_55"));
        pushButton_55->setMinimumSize(QSize(0, 25));

        gridLayout_5->addWidget(pushButton_55, 2, 0, 1, 1);

        pushButton_54 = new QPushButton(groupBox_9);
        pushButton_54->setObjectName(QString::fromUtf8("pushButton_54"));
        pushButton_54->setMinimumSize(QSize(0, 25));

        gridLayout_5->addWidget(pushButton_54, 0, 1, 1, 1);

        pushButton_64 = new QPushButton(groupBox_9);
        pushButton_64->setObjectName(QString::fromUtf8("pushButton_64"));
        pushButton_64->setMinimumSize(QSize(0, 25));

        gridLayout_5->addWidget(pushButton_64, 3, 0, 1, 1);


        verticalLayout_8->addWidget(groupBox_9);

        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/images/images/804.bmp"), QSize(), QIcon::Normal, QIcon::Off);
        toolBox->addItem(pageFile, icon1, QString::fromUtf8("QFile\347\261\273"));
        pageFileInfo = new QWidget();
        pageFileInfo->setObjectName(QString::fromUtf8("pageFileInfo"));
        pageFileInfo->setGeometry(QRect(0, 0, 342, 379));
        verticalLayout_5 = new QVBoxLayout(pageFileInfo);
        verticalLayout_5->setSpacing(3);
        verticalLayout_5->setContentsMargins(11, 11, 11, 11);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        verticalLayout_5->setContentsMargins(3, 3, 3, 3);
        groupBox_6 = new QGroupBox(pageFileInfo);
        groupBox_6->setObjectName(QString::fromUtf8("groupBox_6"));
        gridLayout_4 = new QGridLayout(groupBox_6);
        gridLayout_4->setSpacing(3);
        gridLayout_4->setContentsMargins(11, 11, 11, 11);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        gridLayout_4->setContentsMargins(3, 3, 3, 3);
        pushButton_30 = new QPushButton(groupBox_6);
        pushButton_30->setObjectName(QString::fromUtf8("pushButton_30"));
        pushButton_30->setMinimumSize(QSize(0, 25));

        gridLayout_4->addWidget(pushButton_30, 3, 0, 1, 1);

        pushButton_29 = new QPushButton(groupBox_6);
        pushButton_29->setObjectName(QString::fromUtf8("pushButton_29"));
        pushButton_29->setMinimumSize(QSize(0, 25));

        gridLayout_4->addWidget(pushButton_29, 0, 1, 1, 1);

        pushButton_28 = new QPushButton(groupBox_6);
        pushButton_28->setObjectName(QString::fromUtf8("pushButton_28"));
        pushButton_28->setMinimumSize(QSize(0, 25));

        gridLayout_4->addWidget(pushButton_28, 0, 0, 1, 1);

        pushButton_31 = new QPushButton(groupBox_6);
        pushButton_31->setObjectName(QString::fromUtf8("pushButton_31"));
        pushButton_31->setMinimumSize(QSize(0, 25));

        gridLayout_4->addWidget(pushButton_31, 3, 1, 1, 1);

        pushButton_42 = new QPushButton(groupBox_6);
        pushButton_42->setObjectName(QString::fromUtf8("pushButton_42"));
        pushButton_42->setMinimumSize(QSize(0, 25));

        gridLayout_4->addWidget(pushButton_42, 6, 0, 1, 1);

        pushButton_43 = new QPushButton(groupBox_6);
        pushButton_43->setObjectName(QString::fromUtf8("pushButton_43"));
        pushButton_43->setMinimumSize(QSize(0, 25));

        gridLayout_4->addWidget(pushButton_43, 6, 1, 1, 1);

        pushButton_35 = new QPushButton(groupBox_6);
        pushButton_35->setObjectName(QString::fromUtf8("pushButton_35"));
        pushButton_35->setMinimumSize(QSize(0, 25));

        gridLayout_4->addWidget(pushButton_35, 7, 0, 1, 1);

        pushButton_36 = new QPushButton(groupBox_6);
        pushButton_36->setObjectName(QString::fromUtf8("pushButton_36"));
        pushButton_36->setMinimumSize(QSize(0, 25));

        gridLayout_4->addWidget(pushButton_36, 8, 0, 1, 1);

        pushButton_44 = new QPushButton(groupBox_6);
        pushButton_44->setObjectName(QString::fromUtf8("pushButton_44"));
        pushButton_44->setMinimumSize(QSize(0, 25));

        gridLayout_4->addWidget(pushButton_44, 8, 1, 1, 1);

        pushButton_33 = new QPushButton(groupBox_6);
        pushButton_33->setObjectName(QString::fromUtf8("pushButton_33"));
        pushButton_33->setMinimumSize(QSize(0, 25));

        gridLayout_4->addWidget(pushButton_33, 1, 0, 1, 1);

        pushButton_27 = new QPushButton(groupBox_6);
        pushButton_27->setObjectName(QString::fromUtf8("pushButton_27"));
        pushButton_27->setMinimumSize(QSize(0, 25));

        gridLayout_4->addWidget(pushButton_27, 10, 1, 1, 1);

        pushButton_39 = new QPushButton(groupBox_6);
        pushButton_39->setObjectName(QString::fromUtf8("pushButton_39"));
        pushButton_39->setMinimumSize(QSize(0, 25));

        gridLayout_4->addWidget(pushButton_39, 4, 0, 1, 1);

        pushButton_59 = new QPushButton(groupBox_6);
        pushButton_59->setObjectName(QString::fromUtf8("pushButton_59"));
        pushButton_59->setMinimumSize(QSize(0, 25));

        gridLayout_4->addWidget(pushButton_59, 10, 0, 1, 1);

        pushButton_32 = new QPushButton(groupBox_6);
        pushButton_32->setObjectName(QString::fromUtf8("pushButton_32"));
        pushButton_32->setMinimumSize(QSize(0, 25));

        gridLayout_4->addWidget(pushButton_32, 4, 1, 1, 1);

        pushButton_34 = new QPushButton(groupBox_6);
        pushButton_34->setObjectName(QString::fromUtf8("pushButton_34"));
        pushButton_34->setMinimumSize(QSize(0, 25));

        gridLayout_4->addWidget(pushButton_34, 1, 1, 1, 1);

        pushButton_37 = new QPushButton(groupBox_6);
        pushButton_37->setObjectName(QString::fromUtf8("pushButton_37"));
        pushButton_37->setMinimumSize(QSize(0, 25));

        gridLayout_4->addWidget(pushButton_37, 2, 1, 1, 1);

        pushButton_38 = new QPushButton(groupBox_6);
        pushButton_38->setObjectName(QString::fromUtf8("pushButton_38"));
        pushButton_38->setMinimumSize(QSize(0, 25));

        gridLayout_4->addWidget(pushButton_38, 2, 0, 1, 1);

        pushButton_58 = new QPushButton(groupBox_6);
        pushButton_58->setObjectName(QString::fromUtf8("pushButton_58"));
        pushButton_58->setMinimumSize(QSize(0, 25));

        gridLayout_4->addWidget(pushButton_58, 7, 1, 1, 1);


        verticalLayout_5->addWidget(groupBox_6);

        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/images/images/135.JPG"), QSize(), QIcon::Normal, QIcon::Off);
        toolBox->addItem(pageFileInfo, icon2, QString::fromUtf8("QFileInfo\347\261\273"));
        pageDir = new QWidget();
        pageDir->setObjectName(QString::fromUtf8("pageDir"));
        pageDir->setGeometry(QRect(0, 0, 325, 461));
        verticalLayout_4 = new QVBoxLayout(pageDir);
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setContentsMargins(11, 11, 11, 11);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        groupBox = new QGroupBox(pageDir);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        gridLayout_3 = new QGridLayout(groupBox);
        gridLayout_3->setSpacing(6);
        gridLayout_3->setContentsMargins(11, 11, 11, 11);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        pushButton_8 = new QPushButton(groupBox);
        pushButton_8->setObjectName(QString::fromUtf8("pushButton_8"));
        pushButton_8->setMinimumSize(QSize(0, 25));

        gridLayout_3->addWidget(pushButton_8, 1, 0, 1, 1);

        pushButton_10 = new QPushButton(groupBox);
        pushButton_10->setObjectName(QString::fromUtf8("pushButton_10"));
        pushButton_10->setMinimumSize(QSize(0, 25));

        gridLayout_3->addWidget(pushButton_10, 0, 0, 1, 1);

        pushButton_9 = new QPushButton(groupBox);
        pushButton_9->setObjectName(QString::fromUtf8("pushButton_9"));
        pushButton_9->setMinimumSize(QSize(0, 25));

        gridLayout_3->addWidget(pushButton_9, 0, 1, 1, 1);

        pushButton_7 = new QPushButton(groupBox);
        pushButton_7->setObjectName(QString::fromUtf8("pushButton_7"));
        pushButton_7->setMinimumSize(QSize(0, 25));

        gridLayout_3->addWidget(pushButton_7, 1, 1, 1, 1);

        pushButton_6 = new QPushButton(groupBox);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));
        pushButton_6->setMinimumSize(QSize(0, 25));

        gridLayout_3->addWidget(pushButton_6, 2, 0, 1, 1);

        pushButton_60 = new QPushButton(groupBox);
        pushButton_60->setObjectName(QString::fromUtf8("pushButton_60"));
        pushButton_60->setMinimumSize(QSize(0, 25));

        gridLayout_3->addWidget(pushButton_60, 2, 1, 1, 1);


        verticalLayout_4->addWidget(groupBox);

        groupBox_4 = new QGroupBox(pageDir);
        groupBox_4->setObjectName(QString::fromUtf8("groupBox_4"));
        gridLayout_2 = new QGridLayout(groupBox_4);
        gridLayout_2->setSpacing(6);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        pushButton_20 = new QPushButton(groupBox_4);
        pushButton_20->setObjectName(QString::fromUtf8("pushButton_20"));
        pushButton_20->setMinimumSize(QSize(0, 25));

        gridLayout_2->addWidget(pushButton_20, 0, 0, 1, 1);

        pushButton_22 = new QPushButton(groupBox_4);
        pushButton_22->setObjectName(QString::fromUtf8("pushButton_22"));
        pushButton_22->setMinimumSize(QSize(0, 25));

        gridLayout_2->addWidget(pushButton_22, 2, 0, 1, 1);

        pushButton_23 = new QPushButton(groupBox_4);
        pushButton_23->setObjectName(QString::fromUtf8("pushButton_23"));
        pushButton_23->setMinimumSize(QSize(0, 25));

        gridLayout_2->addWidget(pushButton_23, 2, 1, 1, 1);

        pushButton_26 = new QPushButton(groupBox_4);
        pushButton_26->setObjectName(QString::fromUtf8("pushButton_26"));
        pushButton_26->setMinimumSize(QSize(0, 25));

        gridLayout_2->addWidget(pushButton_26, 3, 0, 1, 1);

        pushButton_24 = new QPushButton(groupBox_4);
        pushButton_24->setObjectName(QString::fromUtf8("pushButton_24"));
        pushButton_24->setMinimumSize(QSize(0, 25));

        gridLayout_2->addWidget(pushButton_24, 0, 1, 1, 1);

        pushButton_12 = new QPushButton(groupBox_4);
        pushButton_12->setObjectName(QString::fromUtf8("pushButton_12"));
        pushButton_12->setMinimumSize(QSize(0, 25));

        gridLayout_2->addWidget(pushButton_12, 3, 1, 1, 1);


        verticalLayout_4->addWidget(groupBox_4);

        groupBox_3 = new QGroupBox(pageDir);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        gridLayout = new QGridLayout(groupBox_3);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        pushButton_19 = new QPushButton(groupBox_3);
        pushButton_19->setObjectName(QString::fromUtf8("pushButton_19"));
        pushButton_19->setMinimumSize(QSize(0, 25));

        gridLayout->addWidget(pushButton_19, 1, 1, 1, 1);

        pushButton_11 = new QPushButton(groupBox_3);
        pushButton_11->setObjectName(QString::fromUtf8("pushButton_11"));
        pushButton_11->setMinimumSize(QSize(0, 25));

        gridLayout->addWidget(pushButton_11, 4, 0, 1, 1);

        pushButton_17 = new QPushButton(groupBox_3);
        pushButton_17->setObjectName(QString::fromUtf8("pushButton_17"));
        pushButton_17->setMinimumSize(QSize(0, 25));

        gridLayout->addWidget(pushButton_17, 4, 1, 1, 1);

        pushButton_14 = new QPushButton(groupBox_3);
        pushButton_14->setObjectName(QString::fromUtf8("pushButton_14"));
        pushButton_14->setMinimumSize(QSize(0, 25));

        gridLayout->addWidget(pushButton_14, 0, 1, 1, 1);

        pushButton_15 = new QPushButton(groupBox_3);
        pushButton_15->setObjectName(QString::fromUtf8("pushButton_15"));
        pushButton_15->setMinimumSize(QSize(0, 25));

        gridLayout->addWidget(pushButton_15, 1, 0, 1, 1);

        pushButton_18 = new QPushButton(groupBox_3);
        pushButton_18->setObjectName(QString::fromUtf8("pushButton_18"));
        pushButton_18->setMinimumSize(QSize(0, 25));

        gridLayout->addWidget(pushButton_18, 3, 0, 1, 1);

        pushButton_13 = new QPushButton(groupBox_3);
        pushButton_13->setObjectName(QString::fromUtf8("pushButton_13"));
        pushButton_13->setMinimumSize(QSize(0, 25));

        gridLayout->addWidget(pushButton_13, 0, 0, 1, 1);

        pushButton_65 = new QPushButton(groupBox_3);
        pushButton_65->setObjectName(QString::fromUtf8("pushButton_65"));
        pushButton_65->setMinimumSize(QSize(0, 25));

        gridLayout->addWidget(pushButton_65, 2, 0, 1, 1);

        pushButton_16 = new QPushButton(groupBox_3);
        pushButton_16->setObjectName(QString::fromUtf8("pushButton_16"));
        pushButton_16->setMinimumSize(QSize(0, 25));

        gridLayout->addWidget(pushButton_16, 2, 1, 1, 1);

        pushButton_66 = new QPushButton(groupBox_3);
        pushButton_66->setObjectName(QString::fromUtf8("pushButton_66"));

        gridLayout->addWidget(pushButton_66, 3, 1, 1, 1);


        verticalLayout_4->addWidget(groupBox_3);

        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/images/images/007.GIF"), QSize(), QIcon::Normal, QIcon::Off);
        toolBox->addItem(pageDir, icon3, QString::fromUtf8("QDir\347\261\273"));
        pageTempDir = new QWidget();
        pageTempDir->setObjectName(QString::fromUtf8("pageTempDir"));
        pageTempDir->setGeometry(QRect(0, 0, 342, 379));
        horizontalLayout_2 = new QHBoxLayout(pageTempDir);
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        groupBox_5 = new QGroupBox(pageTempDir);
        groupBox_5->setObjectName(QString::fromUtf8("groupBox_5"));
        verticalLayout_7 = new QVBoxLayout(groupBox_5);
        verticalLayout_7->setSpacing(6);
        verticalLayout_7->setContentsMargins(11, 11, 11, 11);
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        pushButton_21 = new QPushButton(groupBox_5);
        pushButton_21->setObjectName(QString::fromUtf8("pushButton_21"));
        pushButton_21->setMinimumSize(QSize(0, 25));

        verticalLayout_7->addWidget(pushButton_21);

        pushButton_67 = new QPushButton(groupBox_5);
        pushButton_67->setObjectName(QString::fromUtf8("pushButton_67"));
        pushButton_67->setMinimumSize(QSize(0, 25));

        verticalLayout_7->addWidget(pushButton_67);

        pushButton_68 = new QPushButton(groupBox_5);
        pushButton_68->setObjectName(QString::fromUtf8("pushButton_68"));
        pushButton_68->setMinimumSize(QSize(0, 25));

        verticalLayout_7->addWidget(pushButton_68);


        horizontalLayout_2->addWidget(groupBox_5);

        QIcon icon4;
        icon4.addFile(QString::fromUtf8(":/images/images/806.bmp"), QSize(), QIcon::Normal, QIcon::Off);
        toolBox->addItem(pageTempDir, icon4, QString::fromUtf8("QTemporaryDir\347\261\273"));
        pageTempFile = new QWidget();
        pageTempFile->setObjectName(QString::fromUtf8("pageTempFile"));
        pageTempFile->setGeometry(QRect(0, 0, 342, 379));
        verticalLayout_11 = new QVBoxLayout(pageTempFile);
        verticalLayout_11->setSpacing(6);
        verticalLayout_11->setContentsMargins(11, 11, 11, 11);
        verticalLayout_11->setObjectName(QString::fromUtf8("verticalLayout_11"));
        groupBox_12 = new QGroupBox(pageTempFile);
        groupBox_12->setObjectName(QString::fromUtf8("groupBox_12"));
        verticalLayout_12 = new QVBoxLayout(groupBox_12);
        verticalLayout_12->setSpacing(6);
        verticalLayout_12->setContentsMargins(11, 11, 11, 11);
        verticalLayout_12->setObjectName(QString::fromUtf8("verticalLayout_12"));
        pushButton_25 = new QPushButton(groupBox_12);
        pushButton_25->setObjectName(QString::fromUtf8("pushButton_25"));
        pushButton_25->setMinimumSize(QSize(0, 25));

        verticalLayout_12->addWidget(pushButton_25);

        pushButton_69 = new QPushButton(groupBox_12);
        pushButton_69->setObjectName(QString::fromUtf8("pushButton_69"));

        verticalLayout_12->addWidget(pushButton_69);

        pushButton_70 = new QPushButton(groupBox_12);
        pushButton_70->setObjectName(QString::fromUtf8("pushButton_70"));

        verticalLayout_12->addWidget(pushButton_70);


        verticalLayout_11->addWidget(groupBox_12);

        QIcon icon5;
        icon5.addFile(QString::fromUtf8(":/images/images/174.JPG"), QSize(), QIcon::Normal, QIcon::Off);
        toolBox->addItem(pageTempFile, icon5, QString::fromUtf8("QTemporaryFile\347\261\273"));
        pageWatcher = new QWidget();
        pageWatcher->setObjectName(QString::fromUtf8("pageWatcher"));
        pageWatcher->setGeometry(QRect(0, 0, 342, 379));
        verticalLayout_9 = new QVBoxLayout(pageWatcher);
        verticalLayout_9->setSpacing(6);
        verticalLayout_9->setContentsMargins(11, 11, 11, 11);
        verticalLayout_9->setObjectName(QString::fromUtf8("verticalLayout_9"));
        groupBox_11 = new QGroupBox(pageWatcher);
        groupBox_11->setObjectName(QString::fromUtf8("groupBox_11"));
        verticalLayout_6 = new QVBoxLayout(groupBox_11);
        verticalLayout_6->setSpacing(6);
        verticalLayout_6->setContentsMargins(11, 11, 11, 11);
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        pushButton_46 = new QPushButton(groupBox_11);
        pushButton_46->setObjectName(QString::fromUtf8("pushButton_46"));
        pushButton_46->setMinimumSize(QSize(0, 25));

        verticalLayout_6->addWidget(pushButton_46);

        pushButton_47 = new QPushButton(groupBox_11);
        pushButton_47->setObjectName(QString::fromUtf8("pushButton_47"));
        pushButton_47->setMinimumSize(QSize(0, 25));

        verticalLayout_6->addWidget(pushButton_47);

        pushButton_52 = new QPushButton(groupBox_11);
        pushButton_52->setObjectName(QString::fromUtf8("pushButton_52"));
        pushButton_52->setMinimumSize(QSize(0, 25));

        verticalLayout_6->addWidget(pushButton_52);

        pushButton_57 = new QPushButton(groupBox_11);
        pushButton_57->setObjectName(QString::fromUtf8("pushButton_57"));
        pushButton_57->setMinimumSize(QSize(0, 25));

        verticalLayout_6->addWidget(pushButton_57);


        verticalLayout_9->addWidget(groupBox_11);

        QIcon icon6;
        icon6.addFile(QString::fromUtf8(":/images/images/714.bmp"), QSize(), QIcon::Normal, QIcon::Off);
        toolBox->addItem(pageWatcher, icon6, QString::fromUtf8("QFileSystemWatcher\347\261\273"));
        splitter->addWidget(toolBox);
        groupBox_2 = new QGroupBox(splitter);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        groupBox_2->setFlat(false);
        verticalLayout = new QVBoxLayout(groupBox_2);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        groupBox_7 = new QGroupBox(groupBox_2);
        groupBox_7->setObjectName(QString::fromUtf8("groupBox_7"));
        horizontalLayout = new QHBoxLayout(groupBox_7);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        pushButton_41 = new QPushButton(groupBox_7);
        pushButton_41->setObjectName(QString::fromUtf8("pushButton_41"));
        pushButton_41->setMinimumSize(QSize(0, 30));
        pushButton_41->setIcon(icon3);

        horizontalLayout->addWidget(pushButton_41);

        pushButton_45 = new QPushButton(groupBox_7);
        pushButton_45->setObjectName(QString::fromUtf8("pushButton_45"));
        pushButton_45->setMinimumSize(QSize(0, 30));
        QIcon icon7;
        icon7.addFile(QString::fromUtf8(":/images/images/122.bmp"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_45->setIcon(icon7);

        horizontalLayout->addWidget(pushButton_45);

        pushButton_5 = new QPushButton(groupBox_7);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));
        pushButton_5->setMinimumSize(QSize(0, 30));
        QIcon icon8;
        icon8.addFile(QString::fromUtf8(":/images/images/212.bmp"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_5->setIcon(icon8);

        horizontalLayout->addWidget(pushButton_5);


        verticalLayout->addWidget(groupBox_7);

        gridLayout_6 = new QGridLayout();
        gridLayout_6->setSpacing(6);
        gridLayout_6->setObjectName(QString::fromUtf8("gridLayout_6"));
        label = new QLabel(groupBox_2);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout_6->addWidget(label, 0, 0, 1, 1);

        editFile = new QLineEdit(groupBox_2);
        editFile->setObjectName(QString::fromUtf8("editFile"));
        editFile->setClearButtonEnabled(true);

        gridLayout_6->addWidget(editFile, 0, 1, 1, 1);

        label_2 = new QLabel(groupBox_2);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout_6->addWidget(label_2, 1, 0, 1, 1);

        editDir = new QLineEdit(groupBox_2);
        editDir->setObjectName(QString::fromUtf8("editDir"));
        editDir->setClearButtonEnabled(true);

        gridLayout_6->addWidget(editDir, 1, 1, 1, 1);

        label_3 = new QLabel(groupBox_2);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout_6->addWidget(label_3, 2, 0, 1, 1);

        plainTextEdit = new QPlainTextEdit(groupBox_2);
        plainTextEdit->setObjectName(QString::fromUtf8("plainTextEdit"));
        QFont font1;
        font1.setPointSize(11);
        plainTextEdit->setFont(font1);
        plainTextEdit->setLineWrapMode(QPlainTextEdit::WidgetWidth);

        gridLayout_6->addWidget(plainTextEdit, 2, 1, 1, 1);


        verticalLayout->addLayout(gridLayout_6);

        splitter->addWidget(groupBox_2);

        verticalLayout_10->addWidget(splitter);


        retranslateUi(Dialog);

        toolBox->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(Dialog);
    } // setupUi

    void retranslateUi(QDialog *Dialog)
    {
        Dialog->setWindowTitle(QCoreApplication::translate("Dialog", "\347\233\256\345\275\225\345\222\214\346\226\207\344\273\266\346\223\215\344\275\234", nullptr));
        groupBox_8->setTitle(QString());
#if QT_CONFIG(tooltip)
        pushButton->setToolTip(QCoreApplication::translate("Dialog", "Returns the directory that contains the application executable", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton->setText(QCoreApplication::translate("Dialog", "applicationDirPath()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_2->setToolTip(QCoreApplication::translate("Dialog", "Returns the file path of the application executable", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_2->setText(QCoreApplication::translate("Dialog", "applicationFilePath()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_3->setToolTip(QCoreApplication::translate("Dialog", "This property holds the name of this application", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_3->setText(QCoreApplication::translate("Dialog", "applicationName()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_62->setToolTip(QCoreApplication::translate("Dialog", "set the name of this application", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_62->setText(QCoreApplication::translate("Dialog", "setApplicationName()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_4->setToolTip(QCoreApplication::translate("Dialog", "Returns a list of paths that the application will search when dynamically loading libraries", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_4->setText(QCoreApplication::translate("Dialog", "libraryPaths()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_61->setToolTip(QCoreApplication::translate("Dialog", "This property holds the name of the organization that wrote this application", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_61->setText(QCoreApplication::translate("Dialog", "organizationName()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_40->setToolTip(QCoreApplication::translate("Dialog", "Tells the application to exit with a return code.", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_40->setText(QCoreApplication::translate("Dialog", "exit() \351\200\200\345\207\272\345\272\224\347\224\250\347\250\213\345\272\217", nullptr));
        toolBox->setItemText(toolBox->indexOf(pageApp), QCoreApplication::translate("Dialog", "QCoreApplication\347\261\273", nullptr));
        groupBox_10->setTitle(QCoreApplication::translate("Dialog", "\351\235\231\346\200\201\345\207\275\346\225\260", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_48->setToolTip(QCoreApplication::translate("Dialog", "Copies the file fileName to newName.", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_48->setText(QCoreApplication::translate("Dialog", "copy()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_49->setToolTip(QCoreApplication::translate("Dialog", "Removes the file specified by the fileName given.", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_49->setText(QCoreApplication::translate("Dialog", "remove()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_50->setToolTip(QCoreApplication::translate("Dialog", "Renames the file oldName to newName. ", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_50->setText(QCoreApplication::translate("Dialog", "rename()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_51->setToolTip(QCoreApplication::translate("Dialog", "Returns true if the file specified by fileName exists; otherwise returns false.", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_51->setText(QCoreApplication::translate("Dialog", "exists()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_63->setToolTip(QCoreApplication::translate("Dialog", "Moves a specific file to the trash", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_63->setText(QCoreApplication::translate("Dialog", "moveToTrash()", nullptr));
        groupBox_9->setTitle(QCoreApplication::translate("Dialog", "\346\210\220\345\221\230\345\207\275\346\225\260", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_53->setToolTip(QCoreApplication::translate("Dialog", "Copies the file currently specified by fileName() to a file called newName", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_53->setText(QCoreApplication::translate("Dialog", "copy()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_56->setToolTip(QCoreApplication::translate("Dialog", "Renames the file currently specified by fileName() to newName. Returns true if successful; otherwise returns false.", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_56->setText(QCoreApplication::translate("Dialog", "rename()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_55->setToolTip(QCoreApplication::translate("Dialog", "Removes the file specified by fileName(). Returns true if successful; otherwise returns false.", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_55->setText(QCoreApplication::translate("Dialog", "remove()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_54->setToolTip(QCoreApplication::translate("Dialog", "Returns true if the file specified by fileName() exists; otherwise returns false.", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_54->setText(QCoreApplication::translate("Dialog", "exists()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_64->setToolTip(QCoreApplication::translate("Dialog", "Moves the file specified by fileName() to the trash", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_64->setText(QCoreApplication::translate("Dialog", "moveToTrash()", nullptr));
        toolBox->setItemText(toolBox->indexOf(pageFile), QCoreApplication::translate("Dialog", "QFile\347\261\273", nullptr));
        groupBox_6->setTitle(QCoreApplication::translate("Dialog", "\346\226\207\344\273\266\344\277\241\346\201\257", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_30->setToolTip(QCoreApplication::translate("Dialog", "The base name consists of all characters in the file up to (but not including) the first '.' character", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_30->setText(QCoreApplication::translate("Dialog", "baseName()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_29->setToolTip(QCoreApplication::translate("Dialog", "Returns a file's path absolute path. This doesn't include the file name", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_29->setText(QCoreApplication::translate("Dialog", "absolutePath() ", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_28->setToolTip(QCoreApplication::translate("Dialog", "Returns an absolute path including the file name", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_28->setText(QCoreApplication::translate("Dialog", "absoluteFilePath()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_31->setToolTip(QCoreApplication::translate("Dialog", "The complete base name consists of all characters in the file up to (but not including) the last '.' character", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_31->setText(QCoreApplication::translate("Dialog", "completeBaseName()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_42->setToolTip(QCoreApplication::translate("Dialog", "Returns true if this object points to a directory or to a symbolic link to a directory; otherwise returns false", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_42->setText(QCoreApplication::translate("Dialog", "isDir()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_43->setToolTip(QCoreApplication::translate("Dialog", "Returns true if this object points to a file or to a symbolic link to a file", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_43->setText(QCoreApplication::translate("Dialog", "isFile()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_35->setToolTip(QCoreApplication::translate("Dialog", "Returns true if the file is executable; otherwise returns false.", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_35->setText(QCoreApplication::translate("Dialog", "isExecutable()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_36->setToolTip(QCoreApplication::translate("Dialog", "Returns the date and time when the file was last modified.", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_36->setText(QCoreApplication::translate("Dialog", "lastModified()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_44->setToolTip(QCoreApplication::translate("Dialog", "Returns the date and time when the file was last read (accessed).", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_44->setText(QCoreApplication::translate("Dialog", "lastRead()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_33->setToolTip(QCoreApplication::translate("Dialog", "Returns the name of the file, excluding the path.", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_33->setText(QCoreApplication::translate("Dialog", "fileName()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_27->setToolTip(QCoreApplication::translate("Dialog", "Returns true if the file exists; otherwise returns false", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_27->setText(QCoreApplication::translate("Dialog", "exists()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_39->setToolTip(QCoreApplication::translate("Dialog", "The suffix consists of all characters in the file after (but not including) the last '.'", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_39->setText(QCoreApplication::translate("Dialog", "suffix()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_59->setToolTip(QCoreApplication::translate("Dialog", "Returns true if the file exists; otherwise returns false", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_59->setText(QCoreApplication::translate("Dialog", "\351\235\231\346\200\201\345\207\275\346\225\260exists()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_32->setToolTip(QCoreApplication::translate("Dialog", "The complete suffix consists of all characters in the file after (but not including) the first '.'", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_32->setText(QCoreApplication::translate("Dialog", "completeSuffix()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_34->setToolTip(QCoreApplication::translate("Dialog", "Returns the file name, including the path (which may be absolute or relative).", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_34->setText(QCoreApplication::translate("Dialog", "filePath()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_37->setToolTip(QCoreApplication::translate("Dialog", "Returns the file's path. This doesn't include the file name.", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_37->setText(QCoreApplication::translate("Dialog", "path()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_38->setToolTip(QCoreApplication::translate("Dialog", "Returns the file size in bytes.", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_38->setText(QCoreApplication::translate("Dialog", "size()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_58->setToolTip(QCoreApplication::translate("Dialog", "Returns the date and time when the file was created", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_58->setText(QCoreApplication::translate("Dialog", "birthTime()", nullptr));
        toolBox->setItemText(toolBox->indexOf(pageFileInfo), QCoreApplication::translate("Dialog", "QFileInfo\347\261\273", nullptr));
        groupBox->setTitle(QCoreApplication::translate("Dialog", "\351\235\231\346\200\201\345\207\275\346\225\260", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_8->setToolTip(QCoreApplication::translate("Dialog", "Returns the absolute path of the user's home directory", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_8->setText(QCoreApplication::translate("Dialog", "homePath()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_10->setToolTip(QCoreApplication::translate("Dialog", "Returns the absolute canonical path of the system's temporary directory", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_10->setText(QCoreApplication::translate("Dialog", "tempPath()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_9->setToolTip(QCoreApplication::translate("Dialog", "Returns the absolute path of the root directory", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_9->setText(QCoreApplication::translate("Dialog", "rootPath()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_7->setToolTip(QCoreApplication::translate("Dialog", "Returns a list of the root directories on this system", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_7->setText(QCoreApplication::translate("Dialog", "drives()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_6->setToolTip(QCoreApplication::translate("Dialog", "Returns the absolute path of the application's current directory", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_6->setText(QCoreApplication::translate("Dialog", "currentPath()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_60->setToolTip(QCoreApplication::translate("Dialog", "Sets the application's current working directory to path", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_60->setText(QCoreApplication::translate("Dialog", "setCurrent()", nullptr));
        groupBox_4->setTitle(QCoreApplication::translate("Dialog", "\346\226\207\344\273\266\346\210\226\347\233\256\345\275\225\346\223\215\344\275\234", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_20->setToolTip(QCoreApplication::translate("Dialog", "Creates a sub-directory called dirName.", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_20->setText(QCoreApplication::translate("Dialog", "mkdir()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_22->setToolTip(QCoreApplication::translate("Dialog", "Removes the file, fileName.", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_22->setText(QCoreApplication::translate("Dialog", "remove()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_23->setToolTip(QCoreApplication::translate("Dialog", "Renames a file or directory from oldName to newName", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_23->setText(QCoreApplication::translate("Dialog", "rename()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_26->setToolTip(QCoreApplication::translate("Dialog", "Sets the path of the directory to path", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_26->setText(QCoreApplication::translate("Dialog", "setPath()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_24->setToolTip(QCoreApplication::translate("Dialog", "Removes the directory specified by dirName.", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_24->setText(QCoreApplication::translate("Dialog", "rmdir()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_12->setToolTip(QCoreApplication::translate("Dialog", "Removes the directory, including all its contents.", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_12->setText(QCoreApplication::translate("Dialog", "removeRecursively()", nullptr));
        groupBox_3->setTitle(QCoreApplication::translate("Dialog", "\346\226\207\344\273\266\346\210\226\347\233\256\345\275\225\344\277\241\346\201\257", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_19->setToolTip(QCoreApplication::translate("Dialog", "Returns the path name of a file in the directory", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_19->setText(QCoreApplication::translate("Dialog", "filePath()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_11->setToolTip(QCoreApplication::translate("Dialog", "Returns a list of the names of all the files and directories in the directory", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_11->setText(QCoreApplication::translate("Dialog", "entryList(dir)", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_17->setToolTip(QCoreApplication::translate("Dialog", "Returns a list of the names of all the files and directories in the directory", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_17->setText(QCoreApplication::translate("Dialog", "entryList(file)", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_14->setToolTip(QCoreApplication::translate("Dialog", "Returns the absolute path (a path that starts with \"/\" or with a drive specification)", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_14->setText(QCoreApplication::translate("Dialog", "absolutePath()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_15->setToolTip(QCoreApplication::translate("Dialog", "Returns the canonical path, i.e. a path without symbolic links or redundant \".\" or \"..\" elements.", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_15->setText(QCoreApplication::translate("Dialog", "canonicalPath()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_18->setToolTip(QCoreApplication::translate("Dialog", "Returns true if the directory exists", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_18->setText(QCoreApplication::translate("Dialog", "exists()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_13->setToolTip(QCoreApplication::translate("Dialog", "Returns the absolute path name of a file in the directory", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_13->setText(QCoreApplication::translate("Dialog", "absoluteFilePath()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_65->setToolTip(QCoreApplication::translate("Dialog", "Returns the path", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_65->setText(QCoreApplication::translate("Dialog", "path()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_16->setToolTip(QCoreApplication::translate("Dialog", "Returns the name of the directory", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_16->setText(QCoreApplication::translate("Dialog", "dirName()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_66->setToolTip(QCoreApplication::translate("Dialog", "Returns whether the directory is empty", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_66->setText(QCoreApplication::translate("Dialog", "isEmpty()", nullptr));
        toolBox->setItemText(toolBox->indexOf(pageDir), QCoreApplication::translate("Dialog", "QDir\347\261\273", nullptr));
#if QT_CONFIG(tooltip)
        groupBox_5->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        groupBox_5->setTitle(QString());
#if QT_CONFIG(tooltip)
        pushButton_21->setToolTip(QCoreApplication::translate("Dialog", "\345\234\250QDir::tempPath()\350\277\224\345\233\236\347\232\204\347\263\273\347\273\237\344\270\264\346\227\266\347\233\256\345\275\225\344\270\213\345\210\233\345\273\272\344\270\264\346\227\266\346\226\207\344\273\266\345\244\271", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_21->setText(QCoreApplication::translate("Dialog", "1.\345\234\250\347\263\273\347\273\237\344\270\264\346\227\266\347\233\256\345\275\225\344\270\213\345\210\233\345\273\272\344\270\264\346\227\266\346\226\207\344\273\266\345\244\271", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_67->setToolTip(QCoreApplication::translate("Dialog", "\345\234\250\346\214\207\345\256\232\347\233\256\345\275\225\344\270\213\345\210\233\345\273\272\344\270\264\346\227\266\346\226\207\344\273\266\345\244\271", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_67->setText(QCoreApplication::translate("Dialog", "2.\345\234\250\346\214\207\345\256\232\347\233\256\345\275\225\344\270\213\345\210\233\345\273\272\344\270\264\346\227\266\346\226\207\344\273\266\345\244\271", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_68->setToolTip(QCoreApplication::translate("Dialog", "\345\234\250QDir::currentPath()\350\241\250\347\244\272\347\232\204\345\275\223\345\211\215\347\233\256\345\275\225\344\270\213\345\210\233\345\273\272\344\270\264\346\227\266\346\226\207\344\273\266\345\244\271", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_68->setText(QCoreApplication::translate("Dialog", "3.\345\234\250\345\275\223\345\211\215\347\233\256\345\275\225\344\270\213\345\210\233\345\273\272\344\270\264\346\227\266\346\226\207\344\273\266\345\244\271", nullptr));
        toolBox->setItemText(toolBox->indexOf(pageTempDir), QCoreApplication::translate("Dialog", "QTemporaryDir\347\261\273", nullptr));
        groupBox_12->setTitle(QString());
#if QT_CONFIG(tooltip)
        pushButton_25->setToolTip(QCoreApplication::translate("Dialog", "\345\234\250QDir::tempPath()\350\277\224\345\233\236\347\232\204\347\263\273\347\273\237\344\270\264\346\227\266\347\233\256\345\275\225\344\270\213\345\210\233\345\273\272\344\270\264\346\227\266\346\226\207\344\273\266", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_25->setText(QCoreApplication::translate("Dialog", "1. \345\234\250\347\263\273\347\273\237\344\270\264\346\227\266\347\233\256\345\275\225\344\270\213\345\210\233\345\273\272\344\270\264\346\227\266\346\226\207\344\273\266", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_69->setToolTip(QCoreApplication::translate("Dialog", "\345\234\250\346\214\207\345\256\232\347\233\256\345\275\225\344\270\213\345\210\233\345\273\272\344\270\264\346\227\266\346\226\207\344\273\266", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_69->setText(QCoreApplication::translate("Dialog", "2.\345\234\250\346\214\207\345\256\232\347\233\256\345\275\225\344\270\213\345\210\233\345\273\272\344\270\264\346\227\266\346\226\207\344\273\266", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_70->setToolTip(QCoreApplication::translate("Dialog", "\345\234\250QDir::currentPath()\350\241\250\347\244\272\347\232\204\345\275\223\345\211\215\347\233\256\345\275\225\344\270\213\345\210\233\345\273\272\344\270\264\346\227\266\346\226\207\344\273\266", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_70->setText(QCoreApplication::translate("Dialog", "3.\345\234\250\345\275\223\345\211\215\347\233\256\345\275\225\344\270\213\345\210\233\345\273\272\344\270\264\346\227\266\346\226\207\344\273\266", nullptr));
        toolBox->setItemText(toolBox->indexOf(pageTempFile), QCoreApplication::translate("Dialog", "QTemporaryFile\347\261\273", nullptr));
        groupBox_11->setTitle(QString());
#if QT_CONFIG(tooltip)
        pushButton_46->setToolTip(QCoreApplication::translate("Dialog", "Adds path to the file system watcher if path exists.", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_46->setText(QCoreApplication::translate("Dialog", "addPath()\345\271\266\345\274\200\345\247\213\347\233\221\350\247\206", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_47->setToolTip(QCoreApplication::translate("Dialog", "Removes the specified path from the file system watcher.", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_47->setText(QCoreApplication::translate("Dialog", "removePath()\345\271\266\345\201\234\346\255\242\347\233\221\350\247\206", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_52->setToolTip(QCoreApplication::translate("Dialog", "Returns a list of paths to directories that are being watched.", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_52->setText(QCoreApplication::translate("Dialog", "directories()", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_57->setToolTip(QCoreApplication::translate("Dialog", "Returns a list of paths to files that are being watched.", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_57->setText(QCoreApplication::translate("Dialog", "files()", nullptr));
        toolBox->setItemText(toolBox->indexOf(pageWatcher), QCoreApplication::translate("Dialog", "QFileSystemWatcher\347\261\273", nullptr));
        groupBox_2->setTitle(QString());
        groupBox_7->setTitle(QString());
        pushButton_41->setText(QCoreApplication::translate("Dialog", "\346\211\223\345\274\200\346\226\207\344\273\266", nullptr));
        pushButton_45->setText(QCoreApplication::translate("Dialog", "\346\211\223\345\274\200\347\233\256\345\275\225", nullptr));
        pushButton_5->setText(QCoreApplication::translate("Dialog", "\346\270\205\351\231\244\346\226\207\346\234\254\346\241\206", nullptr));
        label->setText(QCoreApplication::translate("Dialog", "\346\226\207 \344\273\266 ", nullptr));
        label_2->setText(QCoreApplication::translate("Dialog", "\347\233\256 \345\275\225 ", nullptr));
        label_3->setText(QCoreApplication::translate("Dialog", "\344\277\241 \346\201\257 ", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Dialog: public Ui_Dialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOG_H
